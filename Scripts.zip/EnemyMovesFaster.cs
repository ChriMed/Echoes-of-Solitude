using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Makes the enemy move faster (Attach to Enemy Object)
public class EnemyMovement : MonoBehaviour
{
    // Original speed of the enemy
    public float originalSpeed;
    // Current speed of the enemy
    private float currentSpeed;

    private void Start()
    {
        // Initialize current speed with original speed
        currentSpeed = originalSpeed;
    }

    // Method to apply speed boost to the enemy
    public void ApplySpeedBoost(float boostAmount, float duration)
    {
        // Increase the enemy's speed temporarily
        currentSpeed += boostAmount;
        // Start a coroutine to reset the speed after the specified duration
        StartCoroutine(ResetSpeed(duration));
    }

    // Coroutine to reset the speed after a certain duration
    private IEnumerator ResetSpeed(float duration)
    {
        yield return new WaitForSeconds(duration);
        // Reset the speed to its original value
        currentSpeed = originalSpeed;
    }

    private void Update()
    {
        // Move the enemy based on the current speed
        transform.Translate(Vector3.forward * currentSpeed * Time.deltaTime);
    }
}