using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class EnemySpawner : MonoBehaviour
{
    public GameObject enemyPrefab;
    public Transform playerTransform;
    public float spawnDistance = 5f;
    public float chaseDelay = 5f;

    private bool enemySpawned = false;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") && !enemySpawned)
        {
            // Calculate spawn position in front of the player
            Vector3 spawnPosition = playerTransform.position + playerTransform.forward * spawnDistance;

            // Spawn the enemy
            GameObject enemy = Instantiate(enemyPrefab, spawnPosition, Quaternion.identity);

            // Set the enemy's target to the player
            //EnemyAI enemyAI = enemy.GetComponent;
            gameObject.SetActive(false);

        }
    }
}


