using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float walkSpeed = 5f;
    public float runSpeed = 10f;
    //public AudioClip walkingSound;
    //private AudioSource audioSource;
    private bool isRunning = false;
    private bool isPlaying = false;
    AudioManager audioManager;

    private void Awake()
    {
        audioManager = GameObject.FindWithTag("Audio").GetComponent<AudioManager>();
    }

    void Start()
    {
        // Get the AudioSource component attached to the player
        //audioSource = GetComponent<AudioSource>();
        // Set the sound effect clip
        //audioSource.clip = walkingSound;
        // Set the sound effect to loop

    }

    void Update()
    {
        // Check for player input
        float moveSpeed = Input.GetKey(KeyCode.LeftShift) ? runSpeed : walkSpeed;
        isRunning = Input.GetKey(KeyCode.LeftShift);

        // Play the walking sound effect with adjusted pitch
        if (Input.GetAxis("Horizontal") != 0 || Input.GetAxis("Vertical") != 0)
        {
            if (!isPlaying)
            {
                audioManager.PlaySFX(audioManager.PlayerMovement);
                isPlaying = true;
            }
            // Adjust pitch based on whether the player is running or walking
            //audioSource.pitch = pitch;
        }
        else
        {
            isPlaying = false;
            audioManager.StopSFX();
            // Stop playing the sound if the player is not moving
        }
    }
}
