using UnityEngine;
using System.Collections;

public class SpeedBoostItem : MonoBehaviour
{
    // The amount of time to wait before boosting enemy speed
    private float waitTime = 15; // Adjust the time as needed
    private bool hasPlayedAudio2 = false;
    private AudioManager audioManager;
    private EnemyController[] enemies;
    private float[] moveSpeedLogs;
    private int i = 0;
    public float speedBoost = 1.5f;
    private void Awake()
    {
        audioManager = GameObject.FindWithTag("Audio").GetComponent<AudioManager>();

        // Find all GameObjects with the tag "Enemy"
        GameObject[] enemyObjects = GameObject.FindGameObjectsWithTag("Enemy");

        // Initialize the enemies array with the correct size
        enemies = new EnemyController[enemyObjects.Length];
        moveSpeedLogs = new float[enemyObjects.Length];

        // Get the EnemyController component from each GameObject
        for (int i = 0; i < enemyObjects.Length; i++)
        {
            enemies[i] = enemyObjects[i].GetComponent<EnemyController>();
        }
    }
    public void resetMovement()
    {
        i = 0;
        foreach (EnemyController enemy in enemies)
        {
            Debug.Log("We are Resetting Movement");
            enemy.moveSpeed = moveSpeedLogs[i];
            enemy.forceChase(false);
            i++;

        }
    }
    public void stopAudio() { hasPlayedAudio2 = true; }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            if (!hasPlayedAudio2)
            {
                audioManager.PlaySFX(audioManager.EnemyCall);
                Debug.Log("Should Scream Here");
                Invoke("stopAudio", 3);
            }

            // Boost enemy speed
            foreach (EnemyController enemy in enemies)
            {
                moveSpeedLogs[i] = enemy.moveSpeed;
                enemy.moveSpeed = enemy.moveSpeed * speedBoost;
                enemy.forceChase(true);

                Debug.Log("We are in enemy spawn ontrigger");
                // Calculate the direction to move towards the player
                i++;
            }
            Debug.Log("SUCCESSFUL EXIT");
            // Reset enemy speed after the wait time

            Invoke("resetMovement", waitTime);


            // Start coroutine to reset enemy speed after wait time
            gameObject.SetActive(false);

        }


    }

}
