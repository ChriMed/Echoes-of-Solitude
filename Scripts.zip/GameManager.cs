using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class GameManager : MonoBehaviour
{

    //Defines how many times the player will respawn before they will gave to restart the level. "

    [SerializeField] public int lives = 1;
    public int currentScore = 0;
    private int totalScores = 7;

    private void GameOver()
    {
        Debug.Log("Game Over. ");

    }

    private void GameWon()
    {
        Debug.Log("Congratsulations you have found all seven relics");
        SceneManager.LoadScene(4);

    }

    public void ModifyScore(int amount)
    {

        currentScore += amount;
        if (currentScore < 0)
        {
            currentScore = 0;
        }
        Debug.Log("Relic Found " + currentScore + "/" + totalScores);
        if (currentScore == totalScores)
        {
            GameWon();

        }
    }

    public bool SubtractLife()
    {



        if (lives > 0)
        {
            GameOver();

            return true;

        }
        else return false;
    }
    public void LevelComplete()
    {
        Debug.Log("Level Complete");
    }


}

