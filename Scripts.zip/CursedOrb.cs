using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CursedOrb : MonoBehaviour
{
    private GameManager manager;

    // Start is called before the first frame update


    private void Awake()
    {
        manager = FindObjectOfType<GameManager>();
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") == true)
        {
            GameOver();
            SceneManager.LoadScene(3);
        }
    }
    private void GameOver()
    {
        Debug.Log("Game Over ");
    }

}
