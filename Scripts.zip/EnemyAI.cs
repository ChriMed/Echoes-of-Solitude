using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EnemyController : MonoBehaviour
{

    // Other methods and properties of EnemyController class...
    //public AudioSource src;
    //public AudioClip Enemy;
    public Transform player; // Reference to the player's transform
    public float moveSpeed = 5f; // Speed at which the enemy moves
    public float collisionDistance = 1f; // Distance at which the enemy collides with the player
    private bool isChasing = false; // Flag to indicate if the enemy is chasing the player
    private bool hasPlayedAudio = false; // Flag to indicate if the enemy audio has been player
    public bool FastEnemy;
    private bool chaseForced;
    public float speedBoostAmount = 1.5f;
    AudioManager audioManager;


    public void forceChase(bool Case)
    {
        chaseForced = true;

        if (Case == true)
            isChasing = true;
        else
        {
            isChasing = false;
        }

    }

    private void Awake()
    {
        audioManager = GameObject.FindWithTag("Audio").GetComponent<AudioManager>();
    }

    void Update()
    {
        // Check if the player is within collision distance
        if (Vector3.Distance(transform.position, player.position) <= collisionDistance)
        {

            // Perform collision action here, for example, restart the scene
            // You can call a function to restart the scene or perform any other action
            // For example, to restart the scene:
            Debug.Log("You have been found");
            GameOver();
        }
        else if (Vector3.Distance(transform.position, player.position) > 30.0 && !isChasing)
        {
            //Hide enemies too far from our character, let player outrun our enemies.
            //gameObject.SetActive(false);
            //If the player is too far away, do not trigger chase
            hasPlayedAudio = false;
            isChasing = false;
        }
        else
        {
            // ENEMY AGGROS
            //gameObject.SetActive(true);
            // If the player is not within collision distance, start chasing
            isChasing = true;
            if (chaseForced)
            {
                hasPlayedAudio = true;
            }
            if (!hasPlayedAudio)
            {
                audioManager.PlaySFX(audioManager.EnemyScream);
                hasPlayedAudio = true;
                Debug.Log("Should Scream Here");

            }
        }

        // If chasing, move towards the player
        if (isChasing)
        {
            if (FastEnemy)
            {
                Debug.Log("We are boosted");
                moveSpeed = moveSpeed * speedBoostAmount;
                FastEnemy = false;
            }

            // Calculate the direction to move towards the player
            Vector3 direction = (player.position - transform.position).normalized;

            // Move the enemy towards the player
            transform.position += direction * moveSpeed * Time.deltaTime;

            // Rotate towards the player (optional)
            transform.rotation = Quaternion.LookRotation(direction);

        }
    }

    private void GameOver()
    {
        Debug.Log("Game Over. ");
        Scene scene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(3);
    }


}
