using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioManager : MonoBehaviour
{
    // Start is called before the first frame update
    [Header("------Audio Source------")]
    [SerializeField] AudioSource musicSource;
    [SerializeField] AudioSource SFXSource;
    [Header("------Audio Clips------")]
    public AudioClip GameMusic;
    public AudioClip MainMenu;
    public AudioClip DeathScreen;
    public AudioClip TutorialMusic;
    public AudioClip VictoryScreen;

    public AudioClip EnemyCall;
    public AudioClip EnemyScream;
    public AudioClip PlayerMovement;
    public bool Menu, Death, Game, Tutorial,Victory;

    private void Start()
    {
        if (Game == true)
        {
            musicSource.clip = GameMusic;
            musicSource.Play();

        }
        if (Menu == true)
        {
            musicSource.clip = MainMenu;
            musicSource.Play();

        }
        if (Death == true)
        {
            musicSource.clip = DeathScreen;
            musicSource.Play();

        }
        if (Tutorial == true)
        {
            musicSource.clip = TutorialMusic;
            musicSource.Play();

        }
        if (Victory == true)
        {
            musicSource.clip = VictoryScreen;
            musicSource.Play();
        }


    }

    public void PlaySFX(AudioClip clip)
    {
        SFXSource.PlayOneShot(clip);
    }

    public void StopSFX()
    {
        SFXSource.Stop();
    }
}
