using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LavaTrigger : MonoBehaviour
{

    private GameManager manager;

    private void Awake()
    {
        manager = FindObjectOfType<GameManager>();
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player") == true)
        {
            if (manager.SubtractLife() == true)
            {
                SceneManager.LoadScene(1);

            }
        }
    }
}
